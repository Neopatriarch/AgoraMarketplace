/**
 * @fileoverview A service to handle all Nostr network operations.
 * It manages connections to relays and provides functions to fetch and publish events.
 * @filepath ~/projects/agoraMarketPlace/src/services/nostrService.ts
 * @version 0.0.1
 */

import * as nostrTools from 'nostr-tools';

// A list of public relays to connect to.
const RELAYS = [
  'wss://relay.damus.io',
  'wss://nos.lol',
  'wss://relay.snort.social'
];

/**
 * Converts a hexadecimal string to a Uint8Array.
 * This is necessary for the old version of nostr-tools used in this project.
 * @param {string} hexString - The hex string to convert.
 * @returns {Uint8Array} The resulting byte array.
 */
function hexToBytes(hexString: string): Uint8Array {
  const matches = hexString.match(/.{1,2}/g);
  return new Uint8Array(matches ? matches.map(byte => parseInt(byte, 16)) : []);
}

/**
 * Fetches marketplace events from the connected relays.
 * @param {string} userPublicKey - The public key of the current user.
 * @returns {Promise<any[]>} A promise that resolves to an array of event objects.
 */
export async function fetchMarketplaceEvents(userPublicKey: string): Promise<any[]> {
  console.log('Fetching marketplace events...');
  const allEvents: any[] = [];

  // Use a simple filter for now. We can refine this with specific kinds or tags later.
  // Kind 1 is a text note, which is a good general starting point for listings.
  const filter = { kinds: [1] };

  for (const relayUrl of RELAYS) {
    try {
      const relay = await nostrTools.relayInit(relayUrl);
      await relay.connect();
      console.log(`Connected to relay: ${relayUrl}`);

      // Subscribe to events matching the filter.
      const sub = relay.sub([filter]);
      
      sub.on('event', (event: any) => {
        console.log('Received event from', relayUrl, event.id);
        allEvents.push(event);
      });

      sub.on('eose', () => {
        // EOSE = "End of Stored Events". The relay has sent all historical events.
        console.log(`EOSE received from ${relayUrl}. Closing subscription.`);
        sub.close();
        relay.close();
      });

    } catch (error) {
      console.error(`Failed to connect to relay ${relayUrl}:`, error);
    }
  }

  // Wait a moment for all relays to send their events before returning.
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Remove duplicate events based on their ID.
  const uniqueEvents = Array.from(new Map(allEvents.map(event => [event.id, event])).values());
  
  console.log(`Found ${uniqueEvents.length} unique marketplace events.`);
  return uniqueEvents;
}

/**
 * Publishes a new event to the connected relays.
 * @param {string} privateKeyHex - The user's private key in hex format.
 * @param {string} content - The content of the event (e.g., the listing description).
 * @returns {Promise<any>} A promise that resolves to the published event object.
 */
export async function publishEvent(privateKeyHex: string, content: string): Promise<any> {
  console.log('Publishing new event...');
  const privateKeyUint8Array = hexToBytes(privateKeyHex);
  const publicKeyHex = nostrTools.getPublicKey(privateKeyUint8Array);

  // Create a new event. Kind 1 is a text note.
  const event = {
    kind: 1,
    pubkey: publicKeyHex,
    created_at: Math.floor(Date.now() / 1000),
    tags: [], // We can add tags later, e.g., ['t', 'marketplace']
    content: content,
  };

  // Sign the event with the private key.
  const signedEvent = nostrTools.finalizeEvent(event, privateKeyUint8Array);
  console.log('Event signed:', signedEvent.id);

  // Publish the signed event to all relays.
  const publishPromises = RELAYS.map(async (relayUrl) => {
    try {
      const relay = await nostrTools.relayInit(relayUrl);
      await relay.connect();
      console.log(`Publishing to relay: ${relayUrl}`);
      await relay.publish(signedEvent);
      relay.close();
    } catch (error) {
      console.error(`Failed to publish to relay ${relayUrl}:`, error);
    }
  });

  await Promise.all(publishPromises);
  console.log('Event published to all relays.');

  return signedEvent;
}

// @filepath ~/projects/agoraMarketPlace/src/services/nostrService.ts
// @version 0.0.1
