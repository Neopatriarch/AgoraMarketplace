// Filepath: src/App.tsx
// Version: v1.8.3
// Purpose: Make sure WebSocket only connects after "Get Started" is clicked, and log progress at each step

import React, { useEffect, useMemo, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import HomePage from './HomePage';
import ProfilePage from './ProfilePage';
import * as nostrTools from 'nostr-tools';

const bytesToHex = (bytes: Uint8Array): string => {
  let hex = '';
  for (let i = 0; i < bytes.length; i++) hex += bytes[i].toString(16).padStart(2, '0');
  return hex;
};

const getPubkeyFromStoredNsec = (nsec: string): string => {
  const nip19 = (nostrTools as any).nip19;
  if (!nip19?.decode) return '';

  const decoded = nip19.decode(nsec);
  if (!decoded || decoded.type !== 'nsec') return '';

  const data = decoded.data;

  try {
    return (nostrTools as any).getPublicKey(data);
  } catch {
    try {
      if (data instanceof Uint8Array) return (nostrTools as any).getPublicKey(bytesToHex(data));
      if (typeof data === 'string' && /^[0-9a-fA-F]{64}$/.test(data)) return (nostrTools as any).getPublicKey(data.toLowerCase());
    } catch {}
  }

  return '';
};

const App: React.FC = () => {
  const [keyInput, setKeyInput] = useState('');
  const [isSettingUp, setIsSettingUp] = useState(false);
  const [walletPubkey, setWalletPubkey] = useState('');
  const [showProOptions, setShowProOptions] = useState(false);
  const [isWebSocketReady, setIsWebSocketReady] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [setupError, setSetupError] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isStarted, setIsStarted] = useState(false);  // Track if "Get Started" is clicked
  const [keyGenerated, setKeyGenerated] = useState(false);  // Track if key generation is completed
  const [milestone, setMilestone] = useState('Waiting for user to click "Get Started"...');  // Track progress milestones

  const storedKey = localStorage.getItem('agora_privateKey');
  const forceFrontDoor = localStorage.getItem('agora_force_front_door') === '1';

  const derivedPubkey = useMemo(() => {
    if (!storedKey || storedKey === 'extension_used') return '';
    try {
      return getPubkeyFromStoredNsec(storedKey);
    } catch {
      return '';
    }
  }, [storedKey]);

  useEffect(() => {
    if (storedKey !== 'extension_used') return;
    if (!(window as any).nostr?.getPublicKey) return;

    (async () => {
      try {
        const pk = await (window as any).nostr.getPublicKey();
        if (typeof pk === 'string') setWalletPubkey(pk);
      } catch {}
    })();
  }, [storedKey]);

  const hasAccess = (Boolean(derivedPubkey) || storedKey === 'extension_used' || Boolean(walletPubkey)) && !forceFrontDoor && isWebSocketReady && keyGenerated;
  const currentUserPubkey = derivedPubkey || walletPubkey || '';

  const handleGetStarted = () => {
    console.log("Get Started clicked, beginning process...");
    setIsStarted(true);  // Set the state to start the connection after the button click
    setIsSettingUp(true);
    setSetupError('');
    setMilestone('Starting key generation process...');  // Log milestone
    try {
      const nip19 = (nostrTools as any).nip19;
      if (!nip19?.nsecEncode) throw new Error('nip19.nsecEncode missing');

      const sk = (nostrTools as any).generateSecretKey?.();
      if (!sk) throw new Error('generateSecretKey missing');

      const nsec = nip19.nsecEncode(sk);
      if (!nsec || typeof nsec !== 'string' || !nsec.startsWith('nsec')) throw new Error('Failed to generate nsec');

      localStorage.setItem('agora_privateKey', nsec);
      localStorage.removeItem('agora_force_front_door');
      setKeyGenerated(true);  // Key generated successfully
      setMilestone('Key generation successful. Waiting for WebSocket connection...');  // Log milestone
      window.location.reload();  // Refresh to apply new key
    } catch (err) {
      console.warn('Setup failed:', err);
      setSetupError('Setup failed. Please try again.');
      setIsSettingUp(false);
      setMilestone('Key generation failed.');  // Log milestone
    }
  };

  const handleUseMyKey = (e: React.FormEvent) => {
    e.preventDefault();
    const input = keyInput.trim();
    if (!input) return;

    try {
      const nip19 = (nostrTools as any).nip19;
      if (!nip19?.decode) throw new Error('nip19.decode missing');

      nip19.decode(input); // validate
      localStorage.setItem('agora_privateKey', input);
      localStorage.removeItem('agora_force_front_door');
      setKeyGenerated(true);  // Key generated successfully
      setMilestone('Key set from input. Waiting for WebSocket connection...');
      window.location.reload();  // Refresh to apply new key
    } catch {
      alert('Invalid key');
    }
  };

  const handleConnectWallet = async () => {
    if (!(window as any).nostr?.getPublicKey) {
      alert('No wallet found');
      return;
    }
    try {
      await (window as any).nostr.getPublicKey();
      localStorage.setItem('agora_privateKey', 'extension_used');
      localStorage.removeItem('agora_force_front_door');
      setKeyGenerated(true);  // Key generated successfully
      setMilestone('Wallet connected. Waiting for WebSocket connection...');
      window.location.reload();  // Refresh to apply new key
    } catch {
      alert('Wallet denied');
    }
  };

  useEffect(() => {
    if (!isStarted) return;  // Don't start WebSocket connection until "Get Started" is clicked

    const socket = new WebSocket('wss://relay.nostr.band/');
    
    const retryConnection = () => {
      if (retryCount >= 10) {
        setErrorMessage('We are still having trouble connecting. Please check your network.');
        return;
      }

      setRetryCount(prev => prev + 1);
      setIsConnecting(true);

      const delay = Math.min(5000, 1000 * retryCount);  // Increasing delay on retry
      setTimeout(() => {
        socket.close();
        connectToWebSocket();  
      }, delay);
    };

    socket.onopen = () => {
      setIsWebSocketReady(true);
      setIsConnecting(false);
      setErrorMessage('');
      setMilestone('WebSocket connected! Moving to Home page...');  // Log milestone
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      retryConnection();  // Retry silently
    };

    socket.onclose = (event) => {
      console.error('WebSocket closed unexpectedly:', event);
      retryConnection();  // Retry silently
    };

    const connectToWebSocket = () => {
      setIsWebSocketReady(false);
      setIsConnecting(true);
      setErrorMessage('Connecting, please wait...');
      setMilestone('Attempting to reconnect to WebSocket...');
      setTimeout(() => {
        socket.close();
        new WebSocket('wss://relay.nostr.band/');
      }, 1000);
    };

    connectToWebSocket(); // Start connection after button click

    return () => {
      socket.close();
    };
  }, [isStarted]);  // Start WebSocket connection only when "Get Started" is clicked

  if (!hasAccess || isConnecting) {
    return (
      <div
        style={{
          background: '#f5f0e8',
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '20px',
          textAlign: 'center',
        }}
      >
        <h1 style={{ fontSize: '36px', marginBottom: '14px', color: '#333' }}>Agora Marketplace</h1>

        <p style={{ fontSize: '18px', color: '#555', maxWidth: '520px', marginBottom: '22px', lineHeight: '1.5' }}>
          A friendly place for real-world gatherings.
        </p>

        {isConnecting ? (
          <p style={{ fontSize: '18px', color: '#555', marginBottom: '22px' }}>Connecting, please wait...</p>
        ) : (
          <p style={{ fontSize: '18px', color: '#ff6b35', marginBottom: '22px' }}>{errorMessage || 'We\'re having trouble connecting. Please try again.'}</p>
        )}

        <p style={{ fontSize: '16px', color: '#888', marginTop: '15px' }}>
          <strong>Current Milestone:</strong> {milestone}
        </p>

        <button
          onClick={handleGetStarted}
          disabled={isSettingUp || isConnecting}
          style={{
            width: '92%',
            maxWidth: '460px',
            padding: '22px',
            fontSize: '22px',
            background: '#ff6b35',
            color: '#fff',
            border: 'none',
            borderRadius: '22px',
            marginBottom: '14px',
            boxShadow: '0 10px 24px rgba(0,0,0,0.12)',
            opacity: isSettingUp || isConnecting ? 0.7 : 1,
          }}
        >
          {isSettingUp || isConnecting ? 'Setting things up…' : 'Get started'}
        </button>

        {setupError && <p style={{ color: 'red', marginTop: '20px' }}>{setupError}</p>}

        <div style={{ width: '92%', maxWidth: '460px' }}>
          <button
            type="button"
            onClick={() => setShowProOptions((v) => !v)}
            style={{
              width: '100%',
              padding: '12px 14px',
              fontSize: '14px',
              background: 'transparent',
              color: '#444',
              border: '1px solid #d7cbb8',
              borderRadius: '16px',
            }}
          >
            {showProOptions ? 'Hide other options' : 'Other options (Pro)'}
          </button>

          {showProOptions && (
            <div
              style={{
                marginTop: '12px',
                background: '#fffaf2',
                border: '1px solid #e8dccb',
                borderRadius: '18px',
                padding: '14px',
                textAlign: 'left',
              }}
            >
              <div style={{ fontSize: '13px', color: '#666', marginBottom: '10px', lineHeight: '1.4' }}>
                For wallet users or if you already have an <code>nsec</code>.
              </div>

              <button
                onClick={handleConnectWallet}
                disabled={isSettingUp || isConnecting}
                style={{
                  width: '100%',
                  padding: '14px',
                  fontSize: '16px',
                  background: '#6b48ff',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '16px',
                  marginBottom: '12px',
                  opacity: isSettingUp || isConnecting ? 0.7 : 1,
                }}
              >
                Connect wallet
              </button>

              <form onSubmit={handleUseMyKey}>
                <input
                  type="password"
                  placeholder="Paste your nsec"
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  disabled={isSettingUp || isConnecting}
                  style={{
                    width: '100%',
                    padding: '14px',
                    fontSize: '15px',
                    borderRadius: '14px',
                    border: '1px solid #ccc',
                    marginBottom: '10px',
                    opacity: isSettingUp || isConnecting ? 0.7 : 1,
                  }}
                />
                <button
                  type="submit"
                  disabled={isSettingUp || isConnecting}
                  style={{
                    width: '100%',
                    padding: '14px',
                    fontSize: '16px',
                    background: '#333',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '14px',
                    opacity: isSettingUp || isConnecting ? 0.7 : 1,
                  }}
                >
                  Use my key
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage currentUserPubkey={currentUserPubkey} />} />
        <Route path="/profile" element={<ProfilePage userPublicKey={currentUserPubkey} />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;

// --- End of File ---
// Filepath: src/App.tsx
// Version: v1.8.3
