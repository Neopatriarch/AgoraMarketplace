// Filepath: src/components/EventCard.tsx
// Author: Robert Kirkpatrick
// Updated by: ChatGPT
// Version: v1.5.0
// Purpose:
// - Robust image + time detection from JSON, tags, and description
// - Fix "Time not specified" when start is stored in tags
// - Support all-day events (date-only display)
// - Graceful image loading failures (hide image + show link)

import React, { useMemo, useState } from 'react';
import { DateTime } from 'luxon';

interface EventCardProps {
  event: any;
  hostName: string;
  currentUserPubkey: string;
  startTime?: DateTime; // optional; EventCard will compute if missing
  isAttending: boolean;
  comments: any[];
  onToggleRSVP: (eventId: string, event: any, onOpenShareModal?: () => void) => void;
  onPostComment: (eventId: string, content: string) => void;
  onShareAsNote: (event: any) => void;
  onShareEvent: (event: any) => void;
  onZap?: (event: any) => void;
}

const renderContentWithImages = (text: string): React.ReactNode[] => {
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let match;
  let partIndex = 0;

  while ((match = urlRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(<span key={`text-${partIndex++}`}>{text.substring(lastIndex, match.index)}</span>);
    }

    const url = match[0];
    if (/\.(jpeg|jpg|gif|png|webp)(\?.*)?$/i.test(url)) {
      parts.push(
        <img
          key={`img-${partIndex++}`}
          src={url}
          alt="Embedded"
          style={{
            maxWidth: '100%',
            height: 'auto',
            borderRadius: '12px',
            margin: '12px 0',
            display: 'block',
          }}
          onError={(e) => {
            // Hide broken inline images gracefully
            (e.currentTarget as HTMLImageElement).style.display = 'none';
          }}
        />
      );
    } else {
      parts.push(
        <a
          key={`link-${partIndex++}`}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          style={{ color: '#007bff' }}
        >
          {url}
        </a>
      );
    }

    lastIndex = urlRegex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(<span key={`text-${partIndex++}`}>{text.substring(lastIndex)}</span>);
  }

  return parts;
};

function getTagValue(tags: any, name: string): string | undefined {
  if (!Array.isArray(tags)) return undefined;
  const found = tags.find((t: any[]) => Array.isArray(t) && t[0] === name);
  return found?.[1];
}

// Converts common “page” URLs into “direct image” URLs when it’s obvious.
// (Not perfect, but it helps a lot.)
function normalizeImageUrl(url: string): string {
  const u = (url || '').trim();
  if (!u) return '';

  // If already a direct image, keep it.
  if (/\.(jpeg|jpg|gif|png|webp)(\?.*)?$/i.test(u)) return u;

  // Imgur page -> i.imgur direct (best-effort: assume .jpg)
  // https://imgur.com/abcd  -> https://i.imgur.com/abcd.jpg
  // https://imgur.com/gallery/abcd -> https://i.imgur.com/abcd.jpg
  const imgurMatch = u.match(/^https?:\/\/(www\.)?imgur\.com\/(?:gallery\/)?([A-Za-z0-9]+)(?:\?.*)?$/i);
  if (imgurMatch?.[2]) {
    return `https://i.imgur.com/${imgurMatch[2]}.jpg`;
  }

  return u;
}

function firstImageUrlFromText(text: string): string {
  const raw = (text || '').trim();
  if (!raw) return '';
  const m = raw.match(/https?:\/\/\S+\.(jpeg|jpg|gif|png|webp)(\?\S*)?/i);
  return m?.[0] ? m[0] : '';
}

type EventData = {
  name: string;
  location: string;
  description: string;
  image_url: string;
  landingPageUrl: string;
  start?: number; // seconds
  end?: number; // seconds
  allDay?: boolean;
};

function safeParseEventData(event: any): EventData {
  // Defaults
  let data: EventData = {
    name: 'Untitled Gathering',
    location: 'Somewhere',
    description: '',
    image_url: '',
    landingPageUrl: '',
  };

  // 1) Try JSON content
  try {
    const parsed = JSON.parse(event?.content || '{}');
    if (parsed && typeof parsed === 'object') {
      data.name = parsed.name || parsed.title || data.name;
      data.location = parsed.location || data.location;
      data.description = parsed.description || parsed.summary || '';
      data.image_url = parsed.image_url || parsed.imageUrl || '';
      data.landingPageUrl = parsed.landingPageUrl || parsed.url || '';

      // timestamps may be seconds or ms; normalize to seconds
      const startCandidate =
        parsed.start ??
        parsed.start_at ??
        parsed.startTimestamp ??
        parsed.start_timestamp ??
        undefined;

      const endCandidate =
        parsed.end ??
        parsed.end_at ??
        parsed.endTimestamp ??
        parsed.end_timestamp ??
        undefined;

      const toSeconds = (v: any) => {
        if (typeof v !== 'number') return undefined;
        // if ms (very large), convert
        return v > 2_000_000_000 ? Math.floor(v / 1000) : v;
      };

      data.start = toSeconds(startCandidate);
      data.end = toSeconds(endCandidate);

      // optional all-day flag
      if (parsed.allDay === true || parsed.all_day === true) data.allDay = true;
    }
  } catch {
    // ignore; we’ll use tags + raw text fallback below
  }

  // 2) Tags fallback (works for both JSON and non-JSON events)
  const tags = event?.tags;

  const tagTitle = getTagValue(tags, 'title') || getTagValue(tags, 'name');
  if (tagTitle && !data.name) data.name = tagTitle;

  const tagLocation = getTagValue(tags, 'location');
  if (tagLocation && (!data.location || data.location === 'Somewhere')) data.location = tagLocation;

  const tagImage = getTagValue(tags, 'image') || getTagValue(tags, 'image_url') || getTagValue(tags, 'imageUrl');
  if (tagImage && !data.image_url) data.image_url = tagImage;

  const tagUrl = getTagValue(tags, 'url') || getTagValue(tags, 'landingPageUrl');
  if (tagUrl && !data.landingPageUrl) data.landingPageUrl = tagUrl;

  const tagStart = getTagValue(tags, 'start');
  if (tagStart && !data.start) {
    const n = Number(tagStart);
    if (!Number.isNaN(n)) data.start = n > 2_000_000_000 ? Math.floor(n / 1000) : n;
  }

  const tagEnd = getTagValue(tags, 'end');
  if (tagEnd && !data.end) {
    const n = Number(tagEnd);
    if (!Number.isNaN(n)) data.end = n > 2_000_000_000 ? Math.floor(n / 1000) : n;
  }

  const tagAllDay = getTagValue(tags, 'all_day') || getTagValue(tags, 'allDay');
  if (tagAllDay === '1' || tagAllDay === 'true') data.allDay = true;

  // 3) Plain-text fallback: if description is empty, use event.content
  if (!data.description) {
    const raw = (event?.content || '').trim();
    data.description = raw;
  }

  // 4) Image fallback: first image URL inside description
  if (!data.image_url) {
    const fromText = firstImageUrlFromText(data.description);
    if (fromText) data.image_url = fromText;
  }

  // Normalize image URL for common cases (imgur pages etc.)
  data.image_url = normalizeImageUrl(data.image_url);

  return data;
}

const EventCard: React.FC<EventCardProps> = ({
  event,
  hostName,
  currentUserPubkey,
  startTime,
  isAttending,
  comments,
  onToggleRSVP,
  onPostComment,
  onShareAsNote,
  onShareEvent,
  onZap,
}) => {
  const [isCommenting, setIsCommenting] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isPostingComment, setIsPostingComment] = useState(false);
  const [imageOk, setImageOk] = useState(true);

  const eventData = useMemo(() => safeParseEventData(event), [event]);

  // Compute start time if not provided
  const computedStart = useMemo(() => {
    if (startTime) return startTime;
    if (typeof eventData.start === 'number') return DateTime.fromSeconds(eventData.start);
    return null;
  }, [startTime, eventData.start]);

  const computedEnd = useMemo(() => {
    if (typeof eventData.end === 'number') return DateTime.fromSeconds(eventData.end);
    return null;
  }, [eventData.end]);

  const whenText = useMemo(() => {
    if (!computedStart) return 'Time not specified';

    // All-day: show date only
    if (eventData.allDay) {
      return computedStart.toLocaleString(DateTime.DATE_FULL);
    }

    // Timed event:
    if (computedEnd) {
      // same day -> show compact range
      if (computedStart.hasSame(computedEnd, 'day')) {
        return `${computedStart.toLocaleString(DateTime.DATETIME_FULL)} – ${computedEnd.toLocaleString(DateTime.TIME_SIMPLE)}`;
      }
      return `${computedStart.toLocaleString(DateTime.DATETIME_FULL)} – ${computedEnd.toLocaleString(DateTime.DATETIME_FULL)}`;
    }

    return computedStart.toLocaleString(DateTime.DATETIME_FULL);
  }, [computedStart, computedEnd, eventData.allDay]);

  const displayHostName = (() => {
    if (event?.pubkey === currentUserPubkey) {
      const savedName = localStorage.getItem('agora_displayName');
      return savedName && savedName.trim() ? savedName.trim() : hostName;
    }
    return hostName || `${(event?.pubkey || '').substring(0, 8)}...`;
  })();

  const handlePostCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    setIsPostingComment(true);
    await onPostComment(event.id, commentText);
    setCommentText('');
    setIsCommenting(false);
    setIsPostingComment(false);
  };

  const handleZapClick = () => {
    if (!onZap) return;
    onZap(event);
  };

  return (
    <div
      style={{
        background: '#1e1e1e',
        borderRadius: '20px',
        padding: '20px',
        marginBottom: '24px',
        boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
      }}
    >
      {eventData.image_url && imageOk && (
        <img
          src={eventData.image_url}
          alt={eventData.name}
          style={{
            width: '100%',
            aspectRatio: '420 / 750',
            objectFit: 'cover',
            borderRadius: '16px',
            marginBottom: '16px',
          }}
          onError={() => {
            // If the host blocks hotlinking / SSL fails / 401 / etc.
            setImageOk(false);
          }}
        />
      )}

      {!imageOk && eventData.image_url && (
        <p style={{ margin: '0 0 16px 0' }}>
          <a
            href={eventData.image_url}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: '#007bff', fontWeight: '500' }}
          >
            🖼️ View image
          </a>
          <span style={{ color: '#bbbbbb', marginLeft: 8, fontSize: 13 }}>
            (image host blocked embedding)
          </span>
        </p>
      )}

      <h3 style={{ fontSize: '22px', margin: '0 0 12px 0', color: '#f5f5f5' }}>
        {eventData.name}
      </h3>

      <p style={{ margin: '8px 0', opacity: 0.9, color: '#bbbbbb' }}>
        <strong>Hosted by:</strong> {displayHostName}
      </p>

      <p style={{ margin: '8px 0', color: '#bbbbbb' }}>
        <strong>Where:</strong> {eventData.location}
      </p>

      <p style={{ margin: '8px 0', color: '#bbbbbb' }}>
        <strong>When:</strong> {whenText}
      </p>

      {eventData.description && (
        <p style={{ margin: '16px 0', lineHeight: '1.5', color: '#f5f5f5' }}>
          {renderContentWithImages(eventData.description)}
        </p>
      )}

      {eventData.landingPageUrl && eventData.landingPageUrl.trim() && (
        <p style={{ margin: '16px 0' }}>
          <a
            href={eventData.landingPageUrl}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: '#007bff', fontWeight: '500' }}
          >
            🌐 Visit official event page
          </a>
        </p>
      )}

      <div style={{ display: 'flex', gap: '12px', margin: '20px 0', alignItems: 'center' }}>
        <button
          onClick={() => onToggleRSVP(event.id, event)}
          disabled={isPostingComment}
          style={{
            flex: 1,
            padding: '14px',
            fontSize: '16px',
            borderRadius: '12px',
            background: isAttending ? '#333' : '#000',
            color: '#fff',
            border: 'none',
          }}
        >
          {isAttending ? 'Going ✓' : 'I’m going'}
        </button>

        <button
          onClick={handleZapClick}
          disabled={!onZap || isPostingComment}
          aria-label="Say thanks"
          title={onZap ? 'Say thanks' : 'Coming soon'}
          style={{
            padding: '14px 16px',
            fontSize: '18px',
            borderRadius: '12px',
            background: '#333',
            color: '#f5f5f5',
            border: 'none',
            opacity: !onZap ? 0.5 : 1,
          }}
        >
          ⚡
        </button>

        <button
          onClick={() => onShareAsNote(event)}
          disabled={isPostingComment}
          style={{
            padding: '14px 20px',
            fontSize: '16px',
            borderRadius: '12px',
            background: '#333',
            color: '#f5f5f5',
            border: 'none',
          }}
        >
          Share Note
        </button>

        <button
          onClick={() => onShareEvent(event)}
          disabled={isPostingComment}
          style={{
            padding: '14px 20px',
            fontSize: '16px',
            borderRadius: '12px',
            background: '#333',
            color: '#f5f5f5',
            border: 'none',
          }}
        >
          Share Card
        </button>
      </div>

      <div style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px solid #444' }}>
        <h4 style={{ margin: '0 0 12px 0', fontSize: '16px', color: '#f5f5f5' }}>
          Comments ({comments.length})
        </h4>

        {!isCommenting ? (
          <button
            onClick={() => setIsCommenting(true)}
            style={{
              padding: '8px 16px',
              fontSize: '14px',
              background: 'transparent',
              border: '1px solid #666',
              borderRadius: '12px',
              color: '#ccc',
            }}
          >
            Add comment
          </button>
        ) : (
          <form onSubmit={handlePostCommentSubmit} style={{ marginBottom: '16px' }}>
            <textarea
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Say something nice..."
              rows={3}
              required
              style={{
                width: '100%',
                padding: '12px',
                borderRadius: '12px',
                border: '1px solid #444',
                background: '#2a2a2a',
                color: '#f5f5f5',
                fontSize: '15px',
                resize: 'none',
              }}
            />

            <div style={{ marginTop: '8px', display: 'flex', gap: '8px' }}>
              <button
                type="submit"
                disabled={isPostingComment}
                style={{
                  padding: '10px 16px',
                  background: '#000',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '8px',
                }}
              >
                Post
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsCommenting(false);
                  setCommentText('');
                }}
                style={{
                  padding: '10px 16px',
                  background: 'transparent',
                  border: '1px solid #666',
                  borderRadius: '8px',
                  color: '#ccc',
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {comments.map((comment, index) => (
          <div key={comment.id || index} style={{ marginTop: '16px', fontSize: '14px' }}>
            <strong style={{ color: '#f5f5f5' }}>{comment.pubkey.substring(0, 8)}...</strong>
            <span style={{ opacity: 0.6, marginLeft: '8px', color: '#bbbbbb' }}>
              {DateTime.fromSeconds(comment.created_at).toRelative()}
            </span>
            <div style={{ marginTop: '6px', lineHeight: '1.4', color: '#f5f5f5' }}>
              {renderContentWithImages(comment.content)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EventCard;

// --- End of File ---
// Filepath: src/components/EventCard.tsx
// Version: v1.5.0
