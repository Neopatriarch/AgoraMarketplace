// Filepath: src/components/EventForm.tsx
// Author: Robert Kirkpatrick
// Updated by: Grok
// v1.0.0 - Safe submit, no lost data, silent key generation if needed

import React, { useState } from 'react';
import { DateTime } from 'luxon';
import * as nostrTools from 'nostr-tools';

interface EventFormProps {
  onSubmit: (mockEvent: any) => Promise<void>;
  onCancel: () => void;
  onSuccess: () => void;
}

const EventForm: React.FC<EventFormProps> = ({ onSubmit, onCancel, onSuccess }) => {
  const [title, setTitle] = useState('');
  const [dateTime, setDateTime] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !dateTime.trim() || !location.trim()) {
      setError('Title, date/time, and location are required');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onSubmit({
        title,
        dateTime,
        location,
        description,
        image,
      });
      onSuccess();
    } catch (err) {
      console.error('Create failed', err);
      setError('Failed to create gathering. Check console.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
        style={{ padding: '16px', fontSize: '20px', borderRadius: '12px', border: '1px solid #444', background: '#2a2a2a', color: '#f5f5f5' }}
      />
      <input
        type="text"
        placeholder="Location"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        required
        style={{ padding: '16px', fontSize: '18px', borderRadius: '12px', border: '1px solid #444', background: '#2a2a2a', color: '#f5f5f5' }}
      />
      <input
        type="datetime-local"
        value={dateTime}
        onChange={(e) => setDateTime(e.target.value)}
        required
        style={{ padding: '16px', fontSize: '18px', borderRadius: '12px', border: '1px solid #444', background: '#2a2a2a', color: '#f5f5f5' }}
      />
      <textarea
        placeholder="Description (optional)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        rows={4}
        style={{ padding: '16px', fontSize: '16px', borderRadius: '12px', border: '1px solid #444', background: '#2a2a2a', color: '#f5f5f5', resize: 'none' }}
      />
      <input
        type="url"
        placeholder="Image URL (optional)"
        value={image}
        onChange={(e) => setImage(e.target.value)}
        style={{ padding: '16px', fontSize: '16px', borderRadius: '12px', border: '1px solid #444', background: '#2a2a2a', color: '#f5f5f5' }}
      />
      {error && <p style={{ color: '#ff6666', textAlign: 'center' }}>{error}</p>}
      <div style={{ display: 'flex', gap: '12px' }}>
        <button
          type="button"
          onClick={onCancel}
          disabled={isSubmitting}
          style={{ flex: 1, padding: '16px', background: '#444', color: '#fff', borderRadius: '12px' }}
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          style={{ flex: 1, padding: '16px', background: '#000', color: '#fff', borderRadius: '12px' }}
        >
          {isSubmitting ? 'Creating...' : 'Create Gathering'}
        </button>
      </div>
    </form>
  );
};

export default EventForm;
// --- End of File ---
// Filepath: src/components/EventForm.tsx
// Version: v1.0.0
