// File: src/components/EventDetail.tsx
// Version: v1.0.0

import React, { useState } from 'react';
import { useCommentOutbox } from '../hooks/useCommentOutbox';

const EventDetail = ({ event }) => {
  const { addToOutbox, publishComment, getPendingComments } = useCommentOutbox();
  const [commentContent, setCommentContent] = useState('');

  // Handle adding a new comment
  const handleAddComment = () => {
    if (commentContent.trim()) {
      addToOutbox(event.id, commentContent);
      setCommentContent('');
    }
  };

  // Display queued comments for the event
  const pendingComments = getPendingComments().filter(
    (comment) => comment.parentEventId === event.id
  );

  return (
    <div className="event-detail">
      <h2>{event.title}</h2>
      <p>{event.description}</p>

      {/* Comment Input */}
      <textarea
        value={commentContent}
        onChange={(e) => setCommentContent(e.target.value)}
        placeholder="Add a comment"
      ></textarea>
      <button onClick={handleAddComment}>Add Comment</button>

      {/* Display queued comments */}
      <div className="queued-comments">
        {pendingComments.length > 0 ? (
          <div>
            <h3>Queued Comments:</h3>
            {pendingComments.map((comment) => (
              <div key={comment.id} className="queued-comment">
                <p>{comment.content} (Queued)</p>
              </div>
            ))}
          </div>
        ) : (
          <p>No comments yet.</p>
        )}
      </div>
    </div>
  );
};

export default EventDetail;

// End of file: src/components/EventDetail.tsx
// Version: v1.0.0
