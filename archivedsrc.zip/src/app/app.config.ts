/**
 * @fileoverview Provides Angular application-level configuration.
 * This file configures the core services needed by the application, such as
 * routing and the HTTP client, for the standalone AppComponent.
 * @filepath ~/projects/agoraMarketPlace/src/app/app.config.ts
 * @version 0.0.1
 */

import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient()
  ]
};

// @filepath ~/projects/agoraMarketPlace/src/app/app.config.ts
// @version 0.0.1
