/**
 * @fileoverview Defines the routing configuration for the Angular application.
 * Currently, this is a placeholder with no routes, as navigation is handled
 * within the AppComponent. It is required for the app config to function.
 * @filepath ~/projects/agoraMarketPlace/src/app/app.routes.ts
 * @version 0.0.1
 */

import { Routes } from '@angular/router';

export const routes: Routes = [];

// @filepath ~/projects/agoraMarketPlace/src/app/app.routes.ts
// @version 0.0.1
