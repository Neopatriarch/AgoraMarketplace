/**
 * @fileoverview The entry point for the Angular application.
 * It bootstraps the root module, which is now the standalone AppComponent.
 * @filepath ~/projects/agoraMarketPlace/src/main.ts
 * @version 0.0.1
 */

import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));

// @filepath ~/projects/agoraMarketPlace/src/main.ts
// @version 0.0.1
