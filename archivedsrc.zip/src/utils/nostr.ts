// Filepath: src/utils/nostr.ts
// Version: v1.8.0
// Purpose: Implement continuous and aggressive retry logic with multiple relay support for WebSocket connections.

type SocketStateHandler = (connected: boolean) => void;

const RELAY_POOL = [
  'wss://relay.nostr.band/',   // Primary relay
  'wss://relay.nostr.watch/',  // Alternative relay 1
  'wss://relay.nostr.pet/',    // Alternative relay 2
  'wss://relay.nostr.h3z.io/', // Alternative relay 3
  'wss://nostr-pub.wellorder.net/', // Alternative relay 4
  'wss://nostr.wine/',        // Optional experimental
  'wss://nostr.bitcoiner.social/', // Additional relay
];

let ws: WebSocket | null = null;
let currentRelay = 0;
let retryCount = 0;
let isManuallyClosed = false;

// Optional handler to notify app of connection state changes
let connectionStateHandler: SocketStateHandler | null = null;

export const onWebSocketState = (handler: SocketStateHandler) => {
  connectionStateHandler = handler;
};

const notifyState = (connected: boolean) => {
  try {
    if (connectionStateHandler) connectionStateHandler(connected);
  } catch {
    // swallow errors in handlers
  }
};

const MAX_BACKOFF = 30000; // 30s cap
const BASE_RETRY = 1000;   // start at 1s

// Exponential + Jitter backoff
function getBackoffDelay(attempt: number) {
  const exp = Math.min(MAX_BACKOFF, BASE_RETRY * Math.pow(2, attempt));
  const jitter = Math.random() * (exp * 0.4); // +-20%
  return exp + jitter;
}

export function connectToWebSocket() {
  if (isManuallyClosed) return;

  const url = RELAY_POOL[currentRelay];  // Pick the current relay

  ws = new WebSocket(url);  // Create a new WebSocket connection

  ws.onopen = () => {
    console.log(`[WS] connected to ${url}`);
    retryCount = 0;  // Reset the retry count when a connection is successful
    notifyState(true);
  };

  ws.onerror = (error) => {
    console.warn(`[WS] error on ${url}`, error);
    handleWebSocketFailure();  // Handle failure and retry
  };

  ws.onclose = (event) => {
    console.warn(`[WS] closed on ${url}`, event);
    notifyState(false);
    handleWebSocketFailure();  // Handle failure and retry
  };
}

// Handle WebSocket failure and retry with backoff strategy
const handleWebSocketFailure = () => {
  // Try the next relay if current one fails
  if (retryCount >= RELAY_POOL.length) {
    console.log('All relays failed. Starting from the first relay again...');
    currentRelay = 0;  // Reset to the first relay
    retryCount = 0;  // Reset retry count
  } else {
    // Move to the next relay in the pool
    currentRelay = (currentRelay + 1) % RELAY_POOL.length;
    retryCount++;
  }

  // Retry connection with exponentially increasing delay (aggressive retry for the first few attempts)
  const delay = getBackoffDelay(retryCount);
  console.log(`[WS] retry #${retryCount} in ${(delay / 1000).toFixed(1)}s via ${RELAY_POOL[currentRelay]}`);
  setTimeout(connectToWebSocket, delay);  // Retry connection after delay
}

// Call this function when initializing your app or component
connectToWebSocket();

// --- End of File ---
// Filepath: src/utils/nostr.ts
// Version: v1.8.0
