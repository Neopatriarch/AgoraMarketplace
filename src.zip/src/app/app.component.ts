/**
 * @fileoverview The root component of the Agora Marketplace application.
 * It is responsible for orchestrating the top-level view, primarily determining
 * whether to display the onboarding flow or the main application interface
 * based on the user's state. This serves as the main entry point for the
 * application's visual tree.
 * @filepath ~/projects/agoraMarketPlace/src/app/app.component.ts
 * @version 0.0.2
 */

import { Component } from '@angular/core';
import { OnboardingComponent } from './onboarding/onboarding.component';
// Import Ionic components for use in this standalone component's template.
import { IonApp, IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';

@Component({
  selector: 'app-root',
  standalone: true,
  // Add the imported Ionic components to the imports array.
  imports: [OnboardingComponent, IonApp, IonHeader, IonToolbar, IonTitle, IonContent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'agoramarketplace';

  /**
   * A flag to determine if the onboarding component should be shown.
   * In a future iteration, this will be determined by checking for an
   * existing user identity or a flag in local storage. For now, it is
   * set to true to ensure the component is rendered.
   */
  showOnboarding: boolean = true;

  /**
   * Handles the completion of the onboarding process.
   * This method will be passed to the OnboardingComponent and called
   * when the user clicks the 'Continue' button. It updates the state
   * to hide the onboarding view.
   * @returns {void}
   */
  handleOnboardingComplete(): void {
    console.log('Onboarding complete. Transitioning to main marketplace.');
    this.showOnboarding = false;
    // Future logic here would involve navigating to the main marketplace view.
  }
}

// @filepath ~/projects/agoraMarketPlace/src/app/app.component.ts
// @version 0.0.2
